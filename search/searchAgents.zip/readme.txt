Sean Fox
ITCS 3152-001
Homework 1
Pacman Search Algorithms

No particular issues with submitting.  Design decisions were based on a combination of
the PowerPoints from class and my notes from 2215.  The design for UFC is a bit different from
the other two algorithms due to the realization of the Directions built into the states/tuples.  
I have not used Python before, so it took a while to get used to the data types that were 
being used.